// Adriana Gomes da Silva Leocádio Bernardo         2019218086
// Pedro Duarte Santos Henriques                    2019217793

#ifndef server   /* Include guard */
#define server


 /* Udp Message types:
  * 
  * Recieve:
  *  - LOGIN:username:password   //To login a user
  *  - DIRECT:dest_username:Message
  *  - P2P:dest_username
  *  - CREATEGROUP:group_name
  *  
  * Send
  *  - Accepted      //To send if login compleeted with success
  *  - Rejected      //To send if login failed
  *  
  *  - RESCSC:message
  *  - RESP2P:dest_ip:dest_port  //To send the Ip Address to send the P2P message
  *  - RESGROUP:multicast_ip:multicast_port //To send the multicast Ip Address to send the Group message (in case of join/create request)
  *  - MESSAGE:source_userID:string //To send a direct message
  * 
  */


#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <pthread.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <netdb.h>
#include <string.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <arpa/inet.h>

#define BUFLEN	512
#define MAX_LINE 200
#define N_PARAM 6

#define TRUE 1
#define FALSE 0

#define SERVER_IP "10.90.0.2"
//#define SERVER_IP "127.0.0.1"

#define MAX_GROUP_ELEM 10

//client permisions
typedef struct{
  int client_server;
  int P2P;
  int group; 
}permissions;

//Client list
typedef struct client{
  char *user_id;
  char *password;
  permissions perms;
  int logged_in;
  char *ip_address;
  uint16_t logged_in_port;
  struct client *next;
}client;

typedef struct group_ips{
  int first;
  int second;
  int third;
  int fourth;
}group_ips;


typedef struct group{
  char *name;
  char *ip_address;
  uint16_t port;
  struct group *next;
}group;

group *firstgroup;

typedef struct client_list{
  client *first_client;
  int n_clients;
}client_list;

client_list list;

void read_registry_file();
void process_user(char *line);
void add_user(char *user_id, char *address, char *password, int client_server, int P2P, int group);
char * concat(char *s1, char *s2);
void process_client(int client_fd, struct sockaddr_in client_addr);
void erro(char *msg);
void tcp_server();

//UDP SERVER
void udp_server();


int customer_port;
int config_port;
char *file_name;
struct in_addr server_ip;
pid_t udp_server_pid, tcp_server_pid;

#endif